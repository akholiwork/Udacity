References
I mainly used stack overflow and data camp to solve my errors and learn new functions such as:
-Seaborn styles
-to_datetime()
-day_name()
I used Wikipedia to learn more about the "Bolsa Família social welfare program"
